package bgu.spl.mics.application.objects;

public class list<T> {

}
